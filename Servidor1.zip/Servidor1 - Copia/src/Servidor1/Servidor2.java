package Servidor1;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import Servidor1.TrataClientet1;

public class Servidor2 {

    public static void main(String[] args) throws IOException {
        // inicia o servidor
        new Servidor2(12346).executa();
    }

    private int porta;
    private List<PrintStream> clientes;

    public Servidor2 (int porta) {
        this.porta = porta;
        this.clientes = new ArrayList<PrintStream>();
    }

    public void executa () throws IOException {
        ServerSocket servidor = new ServerSocket(this.porta);
        System.out.println("Porta 12345 aberta!");

        while (true) {
            // aceita um cliente
            Socket cliente = servidor.accept();
            System.out.println("Nova conexão com o cliente " + cliente.getInetAddress().getHostAddress());
            
            PrintStream ps = new PrintStream(cliente.getOutputStream());
            this.clientes.add(ps);

            Scanner entrada = new Scanner(cliente.getInputStream());


            while (entrada.hasNextLine()) {

                System.out.println(entrada.nextLine());
                
            }

            // cria tratador de cliente numa nova thread
            TrataClientet1 tratacliente = new TrataClientet1(cliente.getInputStream(), this);
            new Thread(tratacliente).start();
        }

    }

    public void distribuiMensagem(String mensagem) {
        // envia msg para todo mundo
        for (PrintStream cliente : this.clientes) {
            cliente.println(mensagem);
        }
    }
}