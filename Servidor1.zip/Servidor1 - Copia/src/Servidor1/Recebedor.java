package Servidor1;

import java.io.InputStream;
import java.util.Scanner;

public class Recebedor implements Runnable {
    private InputStream servidor;

    public Recebedor(InputStream servidor) {
        this.servidor = servidor;
    }

    public void run() {
        // recebe msgs do servidor e imprime na tela
        Scanner entrada = new Scanner(this.servidor);
        while (entrada.hasNextLine()) {
            System.out.println(entrada.nextLine());
        }
    }
}
