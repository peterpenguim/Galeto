package Servidor1;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import Servidor1.Recebedor;

public class Clientet1 {
    public static void main(String[] args) throws UnknownHostException, IOException {
        new Clientet1("127.0.0.1", 12346).executa();
    }

    private String host;
    private int porta;

    public Clientet1 (String host, int porta) {
        this.host = host;
        this.porta = porta;
    }

    public void executa() throws UnknownHostException, IOException {
        Socket cliente = new Socket(this.host, this.porta);
        System.out.println("O cliente se conectou ao servidor!");

        // thread para receber mensagens do servidor
        Recebedor r = new Recebedor(cliente.getInputStream());
        new Thread(r).start();

        Scanner entrada = new Scanner(System.in);
        PrintStream saida = new PrintStream(cliente.getOutputStream());
        while (entrada.hasNextLine()) {
            saida.println(entrada.nextLine());
        }

        saida.close();
        entrada.close();
        cliente.close();        
    }

}
