package Servidor1;

import java.io.InputStream;
import java.util.Scanner;

public class TrataClientet1 implements Runnable{
    private InputStream cliente;
    private Servidor2 servidor;

    public TrataClientet1(InputStream clientet1, Servidor2 servidor) {
        this.cliente = clientet1;
        this.servidor = servidor;
    }

    public void run() {
        // quando chegar uma msg, distribui pra todos
        Scanner s = new Scanner(this.cliente);
        while (s.hasNextLine()) {
            servidor.distribuiMensagem(s.nextLine());
        }
        s.close();
    }
}
