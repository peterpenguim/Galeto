import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Cliente1 {
	public static void main(String [] args) throws IOException{
		Socket cliente = new Socket("127.0.0.1", 11540);
		System.out.println("Cliente conectado");
		System.out.println("Envie uma mensagem para o servidor: ");
		
		Scanner entrada = new Scanner(System.in);
		PrintStream saida = new PrintStream(cliente.getOutputStream());
		
		
		while (entrada.hasNextLine()) {
			saida.println(entrada.nextLine());
		}
            
        System.out.println("O cliente desconectou.");

        saida.close();
		entrada.close();
		cliente.close();
		
	}
}