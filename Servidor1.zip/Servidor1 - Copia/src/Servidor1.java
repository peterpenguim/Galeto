import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Servidor1 {
	public static void main(String [] args) {
		try {
			ServerSocket servidor = new ServerSocket(11540);
			Socket cliente;
			cliente = servidor.accept();
			
			System.out.println(" o cliente: " + cliente.getInetAddress().getHostAddress() + " conectou.");
            System.out.println("mensagens enviadas pelo cliente:");
		
			Scanner entrada = new Scanner(cliente.getInputStream());
			
			while (entrada.hasNextLine()) {

			System.out.println(entrada.nextLine());
			
		}
			entrada.close();
			servidor.close();
			System.out.println("servidor fechado.");
		
		} catch (IOException e) {

			System.out.println("Erro ao criar o servidor");

		}
		
	}

}